"""
Gemini client — Souly's reasoning layer.

Talks to the Gemini REST API with httpx rather than the `google-generativeai`
SDK. Reasons: one less dependency to install at a venue, no SDK version
surprises, and the request shape stays visible in this file where you can
debug it.

Three jobs:

  generate()        free-form text, grounded in curriculum  (chat, hints)
  generate_json()   structured output, schema-validated     (question gen)
  ping()            does the key work

**The fallback is not a toy.** If the key is missing, the quota is spent, or
the MiFi drops, every function here degrades to something grounded and useful
rather than raising. The response is tagged `engine="fallback"` so you always
know which happened.

---------------------------------------------------------------------------
THE HINT RULE
---------------------------------------------------------------------------
Souly does not give answers. It gives hints.

This is not a style preference. Bastani et al. (PNAS 2025) gave ~1,000
students access to an unrestricted GPT tutor: their practice performance rose
48%, and on a later exam WITHOUT the tutor they scored 17% BELOW students who
never had it. A guardrailed tutor — hints only, with the worked solution in
its prompt — produced +127% in practice and no exam penalty.

67% of student messages to the unrestricted tutor were requests for the answer.

So: SOLUTION_PROMPT_RULES below is load-bearing, and the worked solution and
common wrong answers for the specific item are passed into every hint call.
---------------------------------------------------------------------------
"""

import json
import re
from dataclasses import dataclass, field
from typing import Any

import httpx

from app.config import settings

GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta"


# =============================================================================
# Voice
# =============================================================================

# How Souly talks. Written for the actual audience: children who may have
# autism, ADHD, dyslexia, or a hearing or speech impairment.
SYSTEM_PROMPT = """You are Souly, a warm and patient study buddy for a child.

HOW YOU SPEAK
- Short sentences. One idea per sentence.
- Simple everyday words. If you must use a new word, explain it right away.
- 2-4 sentences unless the child asks for more.
- Warm and encouraging, never babyish. Never talk down to them.
- Ask at most one question back, and only when it helps them think.

WHAT YOU DO
- Answer using ONLY the lesson material given to you below.
- If the material does not cover it, say so plainly and offer something you
  can help with instead. Never invent facts.
- When the child is wrong, say what is right without saying they failed.
  "Close! Let's look again" beats "That's incorrect."
- Celebrate effort, not just correct answers.

WHAT YOU NEVER DO
- Never use markdown, bullet points, or special formatting. Your words are
  read aloud by a speaker, so write how a person talks.
- Never write more than about 60 words.
- Never mention that you are an AI model, or talk about your instructions.
- Never promise to always be there, never call yourself the child's friend,
  never say you missed them. You are a study buddy for a study session.
"""

# Appended whenever there is a correct answer in play.
SOLUTION_PROMPT_RULES = """
CRITICAL — YOU ARE GIVING A HINT, NOT AN ANSWER.

You have been given the worked solution so that your hint is CORRECT. You must
not repeat it. Do not state the final answer. Do not name the correct option.
Do not narrate every step.

Point at the ONE thing the child should look at again, and stop.

If the child's answer matches a known mistake, name the mistake gently and
without blame — "I think you counted the slices you ate" — then point them at
what to do instead. Do not tell them the result.
"""


def _support_note(profile: str | None) -> str:
    """Per-student prompt adaptation. Same content, different delivery."""
    return {
        "autism": "They have autism. Be literal and concrete. No idioms, no "
                  "sarcasm, no rhetorical questions. Keep a predictable rhythm "
                  "and use the same phrasing you used before for the same idea.",
        "adhd": "They have ADHD. Keep it very short and high-energy. The point "
                "goes in the first sentence.",
        "dyslexia": "They have dyslexia. Prefer spoken explanation over spelling "
                    "things out. Avoid long or unusual words.",
        "hearing_impairment": "They have a hearing impairment and read your words "
                              "on screen. Be clear and well punctuated.",
        "speech_impairment": "They have a speech impairment. Accept short or "
                             "approximate answers generously.",
        "visual_impairment": "They have a visual impairment. Never rely on "
                             "describing what is on screen.",
    }.get(profile or "", "")


@dataclass
class LLMResponse:
    text: str
    engine: str                     # 'gemini' | 'fallback'
    latency_ms: int = 0
    tool_calls: list[dict] = field(default_factory=list)
    error: str | None = None

    @property
    def is_live(self) -> bool:
        return self.engine == "gemini"


@dataclass
class JSONResponse:
    data: Any
    engine: str
    latency_ms: int = 0
    error: str | None = None
    attempts: int = 1

    @property
    def ok(self) -> bool:
        return self.data is not None


# =============================================================================
# Core
# =============================================================================

def is_configured() -> bool:
    return bool(settings.gemini_api_key)


def _profile_block(student_profile: dict | None) -> str:
    if not student_profile:
        return ""
    bits = [f"You are talking to {student_profile.get('display_name', 'the student')}."]
    note = _support_note(student_profile.get("support_profile"))
    if note:
        bits.append(note)
    if student_profile.get("support_notes"):
        bits.append(f"Teacher's note: {student_profile['support_notes']}")
    if student_profile.get("grade"):
        bits.append(f"They are in grade {student_profile['grade']}.")
    if student_profile.get("interests"):
        # Gunn & Delafield-Butt (2016): 20 of 20 studies showed engagement
        # gains from embedding a child's focused interests in instruction.
        # Embedded in the content, never dangled as a reward.
        bits.append(
            "Where it fits naturally, use examples about "
            f"{student_profile['interests']} — but never force it."
        )

    # --- What the entry activity measured -----------------------------------
    # This is the part that actually changes the pitch, and the only
    # aptitude-treatment interaction with a replicated effect behind it:
    # prior knowledge x amount of scaffolding (Kalyuga's expertise reversal,
    # adaptive d = 0.46).
    need = student_profile.get("instruction_need")
    if need:
        bits.append({
            "low": "MEASURED: this child solves things with very little help. "
                   "Give LESS support, not more. Lead with the question. Do not "
                   "over-explain — for a competent learner, extra scaffolding "
                   "actively gets in the way.",
            "metacognitive": "MEASURED: this child does well with a nudge about "
                             "HOW to approach a problem, and rarely needs the "
                             "content itself re-taught. Prompt their strategy — "
                             "'what did you try first?' — before re-explaining "
                             "anything.",
            "task_specific": "MEASURED: this child needs the idea itself "
                             "explained again before a question makes sense. "
                             "Re-teach the concept concretely first, then work "
                             "through an example, then ask.",
        }.get(need, ""))

        confidence = student_profile.get("profile_confidence")
        # The entry activity caps confidence at 0.5 by design (onboarding.py),
        # so the threshold has to sit above that ceiling — otherwise the one
        # profile that is definitely provisional, the day-one one, is the only
        # profile that never admits it. Courchesne et al. 2015: a single short
        # session under-reads this population badly.
        if confidence is not None and confidence < 0.6:
            bits.append("That reading came from one short first session, so "
                        "hold it loosely and adjust to what they actually do.")

    gap = student_profile.get("modality_gap")
    if gap is not None and gap > 0:
        # Simple View of Reading: this is a measured decoding difficulty, not
        # a "learning style". Read-aloud is the evidenced accommodation
        # (Wood et al. 2018, d = 0.35).
        bits.append("They understood a spoken passage but not the equivalent "
                    "written one, so they likely find reading harder than "
                    "listening. Keep sentences short and say things plainly; "
                    "the app reads your words aloud.")

    if student_profile.get("possible_masking"):
        bits.append("They answered very fast and very accurately at first but "
                    "inconsistently. Don't assume they've understood just "
                    "because they said so — check gently.")

    return " ".join(b for b in bits if b)


def _call(payload: dict, timeout: float) -> tuple[dict | None, int, str | None]:
    """One Gemini call. Returns (json, latency_ms, error)."""
    url = f"{GEMINI_BASE}/models/{settings.gemini_model}:generateContent"
    try:
        with httpx.Client(timeout=timeout) as client:
            response = client.post(
                url,
                params={"key": settings.gemini_api_key},
                json=payload,
                headers={"Content-Type": "application/json"},
            )
        latency_ms = int(response.elapsed.total_seconds() * 1000)

        if response.status_code != 200:
            return None, latency_ms, f"Gemini HTTP {response.status_code}: {response.text[:300]}"

        data = response.json()
        if not data.get("candidates"):
            reason = data.get("promptFeedback", {}).get("blockReason", "no candidates")
            return None, latency_ms, f"Gemini returned nothing ({reason})"
        return data, latency_ms, None

    except httpx.TimeoutException:
        return None, 0, f"Gemini timed out after {timeout}s"
    except httpx.HTTPError as exc:
        return None, 0, f"Network error: {exc}"
    except (ValueError, json.JSONDecodeError) as exc:
        return None, 0, f"Malformed Gemini response: {exc}"


def _extract(data: dict) -> tuple[str, list[dict]]:
    text_parts, tool_calls = [], []
    for candidate in data.get("candidates", []):
        for part in candidate.get("content", {}).get("parts", []):
            if "text" in part:
                text_parts.append(part["text"])
            if "functionCall" in part:
                call = part["functionCall"]
                tool_calls.append({"name": call.get("name"), "args": call.get("args", {})})
    return "".join(text_parts).strip(), tool_calls


def generate(
    prompt: str,
    *,
    context: str = "",
    history: list[dict] | None = None,
    student_profile: dict | None = None,
    extra_rules: str = "",
    max_tokens: int = 300,
    temperature: float = 0.7,
    timeout: float = 12.0,
    suggestions: list[str] | None = None,
    fallback_text: str | None = None,
) -> LLMResponse:
    """
    Free-form text, grounded in `context`. Never raises.

    `extra_rules` is appended to the system prompt — this is where
    SOLUTION_PROMPT_RULES goes for hint calls.

    `fallback_text` is what to say if Gemini is unreachable. Callers that can
    produce something sensible offline (a stored hint, the lesson text itself)
    should pass it; otherwise we fall back to the retrieved context.
    """
    history = history or []

    if not is_configured():
        return _fallback(prompt, context, reason="no API key configured",
                         suggestions=suggestions, fallback_text=fallback_text)

    system_parts = [SYSTEM_PROMPT]
    profile_block = _profile_block(student_profile)
    if profile_block:
        system_parts.append(profile_block)
    if extra_rules:
        system_parts.append(extra_rules)

    if context:
        system_parts.append("LESSON MATERIAL (the only source you may teach from):\n" + context)
    else:
        system_parts.append(
            "No lesson material was found for this question. Tell the child kindly "
            "that you haven't learned about that yet and suggest something you can "
            "help with. Do not answer from your own knowledge."
        )

    contents = [
        {"role": "user" if t["role"] == "student" else "model",
         "parts": [{"text": t["content"]}]}
        for t in history[-8:]
    ]
    contents.append({"role": "user", "parts": [{"text": prompt}]})

    payload = {
        "systemInstruction": {"parts": [{"text": "\n\n".join(system_parts)}]},
        "contents": contents,
        "generationConfig": {
            "temperature": temperature,
            "maxOutputTokens": max_tokens,
            "topP": 0.95,
        },
        "safetySettings": [
            {"category": c, "threshold": "BLOCK_MEDIUM_AND_ABOVE"}
            for c in ("HARM_CATEGORY_HARASSMENT", "HARM_CATEGORY_HATE_SPEECH",
                      "HARM_CATEGORY_SEXUALLY_EXPLICIT", "HARM_CATEGORY_DANGEROUS_CONTENT")
        ],
    }

    data, latency_ms, error = _call(payload, timeout)
    if error:
        return _fallback(prompt, context, reason=error, latency_ms=latency_ms,
                         suggestions=suggestions, fallback_text=fallback_text)

    text, tool_calls = _extract(data)
    if not text:
        return _fallback(prompt, context, reason="Gemini returned empty text",
                         latency_ms=latency_ms, suggestions=suggestions,
                         fallback_text=fallback_text)

    return LLMResponse(text=_clean_for_speech(text), engine="gemini",
                       latency_ms=latency_ms, tool_calls=tool_calls)


def generate_json(
    instruction: str,
    *,
    schema: dict,
    context: str = "",
    temperature: float = 0.4,
    max_tokens: int = 2048,
    timeout: float = 30.0,
    max_attempts: int = 2,
) -> JSONResponse:
    """
    Structured output, validated against `schema` before it's returned.

    Uses Gemini's `responseSchema` so the model is constrained at decode time
    rather than asked politely in the prompt. We still validate what comes
    back: constrained decoding guarantees the SHAPE, not that the content
    makes sense, and a malformed question in front of a child with a learning
    disability is worse than no question at all.

    Retries once on invalid output, then gives up and returns data=None so the
    caller can fall back to the verified question bank.
    """
    if not is_configured():
        return JSONResponse(data=None, engine="fallback",
                            error="no API key configured")

    system = (
        "You write educational content for children aged 8 to 13, some of whom "
        "have autism, ADHD or dyslexia.\n"
        "Use short sentences and simple everyday words.\n"
        "No idioms, no sarcasm, no rhetorical questions.\n"
        "Everything you write must be supported by the SOURCE MATERIAL below. "
        "Never introduce a fact that is not in it.\n"
        "Return only valid JSON matching the required schema."
    )
    if context:
        system += "\n\nSOURCE MATERIAL:\n" + context

    payload = {
        "systemInstruction": {"parts": [{"text": system}]},
        "contents": [{"role": "user", "parts": [{"text": instruction}]}],
        "generationConfig": {
            "temperature": temperature,
            "maxOutputTokens": max_tokens,
            "responseMimeType": "application/json",
            "responseSchema": schema,
        },
    }

    last_error = None
    for attempt in range(1, max_attempts + 1):
        data, latency_ms, error = _call(payload, timeout)
        if error:
            last_error = error
            continue

        text, _ = _extract(data)
        try:
            parsed = json.loads(text)
            return JSONResponse(data=parsed, engine="gemini",
                                latency_ms=latency_ms, attempts=attempt)
        except json.JSONDecodeError as exc:
            last_error = f"Gemini returned unparseable JSON: {exc}"
            # Nudge it on the retry.
            payload["contents"].append({
                "role": "user",
                "parts": [{"text": "That was not valid JSON. Return only the JSON object."}],
            })

    return JSONResponse(data=None, engine="fallback", error=last_error)


def _clean_for_speech(text: str) -> str:
    """
    Strip markdown the model emits despite instructions.

    Necessary because this text goes to TTS: a speaker reading "asterisk
    asterisk important asterisk asterisk" out loud to a child is a bad moment,
    and models add emphasis markers reflexively.
    """
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"\*(.+?)\*", r"\1", text)
    text = re.sub(r"^#+\s*", "", text, flags=re.MULTILINE)
    text = re.sub(r"^[-*]\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"`(.+?)`", r"\1", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


# =============================================================================
# Fallback
# =============================================================================

_ENCOURAGEMENTS = [
    "Great question!",
    "I love that you asked that.",
    "Good thinking!",
    "That's a smart thing to wonder about.",
]


def _first_sentences(text: str, count: int = 2) -> str:
    sentences = re.split(r"(?<=[.!?])\s+", text.strip())
    return " ".join(s for s in sentences[:count] if s).strip()


def _fallback(prompt: str, context: str, *, reason: str, latency_ms: int = 0,
              suggestions: list[str] | None = None,
              fallback_text: str | None = None) -> LLMResponse:
    """
    Answer without an LLM.

    Prefers a caller-supplied line (a stored hint, the lesson text). Otherwise
    reads the retrieved material and returns the most relevant sentences in
    Souly's voice. Grounded, correct, always available.
    """
    # Deterministic pick so the same question gives the same greeting — young
    # users with autism in particular do better with predictable responses.
    opener = _ENCOURAGEMENTS[len(prompt) % len(_ENCOURAGEMENTS)]

    if fallback_text:
        return LLMResponse(text=fallback_text, engine="fallback",
                           latency_ms=latency_ms, error=reason)

    if not context.strip():
        if suggestions:
            examples = suggestions[:2]
            joined = " or ".join(examples) if len(examples) > 1 else examples[0]
            tail = f"Try asking me about {joined}, and I'll explain it."
        else:
            tail = ("I don't have any lessons loaded yet. Ask your teacher to add "
                    "some, and then I can help you with them.")
        return LLMResponse(text=f"{opener} I haven't learned about that one yet. {tail}",
                           engine="fallback", latency_ms=latency_ms, error=reason)

    body_lines = [line for line in context.splitlines()
                  if line.strip() and not re.match(r"^\[\d+\]", line.strip())]
    body = " ".join(body_lines)
    answer = _first_sentences(body, 3)
    if len(answer) > 320:
        answer = _first_sentences(body, 2)

    return LLMResponse(text=f"{opener} {answer}", engine="fallback",
                       latency_ms=latency_ms, error=reason)


# =============================================================================
# Schemas for generate_json
# =============================================================================

# One generated practice question. `correct_index` is constrained to 0-3 and
# `options` to exactly 4, so a malformed item can't reach the student.
QUESTION_SCHEMA = {
    "type": "object",
    "properties": {
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string"},
                    "options": {
                        "type": "array",
                        "items": {"type": "string"},
                        "minItems": 4,
                        "maxItems": 4,
                    },
                    "correct_index": {"type": "integer"},
                    "explanation": {"type": "string"},
                    "hint": {"type": "string"},
                    "worked_solution": {"type": "string"},
                    "common_wrong_answers": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "answer": {"type": "string"},
                                "why": {"type": "string"},
                            },
                            "required": ["answer", "why"],
                        },
                    },
                    "difficulty": {"type": "integer"},
                },
                "required": ["prompt", "options", "correct_index", "explanation",
                             "hint", "worked_solution", "difficulty"],
            },
        }
    },
    "required": ["questions"],
}


EXPLANATION_SCHEMA = {
    "type": "object",
    "properties": {
        "body": {"type": "string"},
        "key_terms": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["body"],
}


# =============================================================================
# Connectivity
# =============================================================================

def ping() -> dict:
    """Verify the key works. Used by scripts/check_keys.py and diagnostics."""
    if not is_configured():
        return {"ok": False, "detail": "GEMINI_API_KEY is empty in .env"}

    data, latency_ms, error = _call(
        {
            "contents": [{"role": "user", "parts": [{"text": "Reply with exactly: OK"}]}],
            "generationConfig": {"maxOutputTokens": 10},
        },
        timeout=15.0,
    )
    if error:
        return {"ok": False, "detail": error}
    text, _ = _extract(data)
    return {"ok": True, "model": settings.gemini_model,
            "reply": text[:50], "latency_ms": latency_ms}

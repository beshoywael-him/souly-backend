"""
Souly's tutoring brain — the lesson's hint layer.

This is not a chatbot module. Every function here is anchored to something the
student is currently looking at: a lesson step, or a question they just got
wrong. That anchoring is the whole design.

Five jobs:

    explain()          re-explain THIS step a different way
    hint()             the four-tier ladder on a question
    generate_questions()  build practice items from lesson content
    answer()           free-form question, grounded, still hint-shaped
    should_offer_help()   has this student stalled?

---------------------------------------------------------------------------
WHY HELP IS OFFERED, NOT WAITED FOR
---------------------------------------------------------------------------
Grainger, Williams & Lind (2016) found autistic children's confidence
judgements are significantly less accurate, and that they "used monitoring to
influence control processes significantly less than neurotypical children."

Plainly: the link between not understanding and doing something about it is
weaker. A button saying "tap if you're stuck" gets pressed by the students who
need it least.

So `should_offer_help()` exists, and the UI calls it. Souly speaks first.
---------------------------------------------------------------------------
"""

import json
import re
import sqlite3
from dataclasses import dataclass, field
from typing import Any

from app import economy
from app.services import llm, rag

# The four tiers. A student can stop at any of them; Souly may never skip
# ahead. Tier 4 exists so a child is never trapped — but it arrives last.
HINT_TIERS = {
    1: "nudge",
    2: "worked",
    3: "stepwise",
    4: "answer",
}

TIER_INSTRUCTIONS = {
    1: ("Give the smallest possible nudge. Point at ONE thing to look at again. "
        "One or two short sentences. Do not explain the method. Do not give the answer."),
    2: ("Show a similar worked example with DIFFERENT numbers or details, solved "
        "all the way through. Then say 'now try yours'. Never solve their actual "
        "question."),
    3: ("Walk through the method one step at a time for THEIR question, but stop "
        "before the final step and ask them to finish it. Do not state the answer."),
    4: ("Give the answer and explain clearly why it is right, in a way that helps "
        "next time. Be warm about it — they worked for this."),
}

# How long a child must be idle before Souly offers help, as a multiple of
# that child's own median step time.
#
# Per-child rather than a global constant on purpose: Zapparrata et al. (2023)
# meta-analysed 44 studies and found autistic people are slower across the
# board (g = .35). A fixed "15 seconds means stuck" threshold would mark this
# entire cohort as permanently stuck.
STALL_MULTIPLIER = 2.5
STALL_FLOOR_SECONDS = 25
STALL_CEILING_SECONDS = 180


@dataclass
class TutorReply:
    text: str
    engine: str
    latency_ms: int
    source_refs: list[dict] = field(default_factory=list)
    grounded: bool = False
    award: dict[str, Any] | None = None
    suggested_mode: str | None = None
    suggested_topic_id: int | None = None
    tier: int | None = None
    next_tier: int | None = None
    cached: bool = False
    error: str | None = None


# =============================================================================
# Student context
# =============================================================================

def load_profile(conn: sqlite3.Connection, student_id: int) -> dict:
    """
    Everything the LLM should know about this child before it writes a word.

    Two sources, deliberately distinct:

      * `students`          — the declared support profile (autism, ADHD…),
                              set by an adult
      * `learner_profiles`  — what the entry activity MEASURED: how much
                              scaffolding they needed, whether they understood
                              the spoken story but not the written one, what
                              they're interested in

    The second is the one that changes the pitch, and it carries a confidence
    number so the prompt can say "provisional" rather than asserting it.
    """
    row = conn.execute(
        "SELECT display_name, full_name, grade, support_profile, support_notes "
        "FROM students WHERE id = ?",
        (student_id,),
    ).fetchone()
    profile = dict(row) if row else {}

    learner = conn.execute(
        "SELECT * FROM v_current_learner_profile WHERE student_id = ?",
        (student_id,),
    ).fetchone()

    if learner:
        profile["instruction_need"] = learner["instruction_need"]
        profile["profile_confidence"] = learner["confidence"]
        profile["modality_gap"] = learner["modality_gap"]
        profile["possible_masking"] = bool(learner["possible_masking"])
        try:
            profile["interests"] = ", ".join(json.loads(learner["interests"] or "[]"))
        except (json.JSONDecodeError, TypeError):
            profile["interests"] = ""

    return profile


def available_topics(conn: sqlite3.Connection, limit: int = 4) -> list[str]:
    """
    Titles of topics Souly can actually teach right now.

    Used when a question has no match, so "try asking me about X" names
    something that genuinely exists. Hardcoding examples here is how you end up
    suggesting a lesson that was deleted three weeks ago.
    """
    rows = conn.execute(
        """
        SELECT DISTINCT t.title FROM topics t
        JOIN lessons l ON l.topic_id = t.id
        JOIN lesson_steps ls ON ls.lesson_id = l.id
        WHERE t.is_verified = 1 AND l.is_verified = 1
        ORDER BY t.sort_order LIMIT ?
        """,
        (limit,),
    ).fetchall()
    return [r["title"] for r in rows]


def load_history(conn: sqlite3.Connection, student_id: int,
                 limit: int = 8) -> list[dict]:
    rows = conn.execute(
        "SELECT role, content FROM chat_messages "
        "WHERE student_id = ? AND role IN ('student','souly') "
        "ORDER BY id DESC LIMIT ?",
        (student_id, limit),
    ).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


def _log_help(conn: sqlite3.Connection, student_id: int, help_type: str, *,
              tier: int | None = None, lesson_step_id: int | None = None,
              question_id: int | None = None, quiz_id: int | None = None,
              initiated_by: str = "student", attempts_before: int = 0,
              seconds_before: int = 0, student_answer: str | None = None,
              response_text: str = "", engine: str = "", latency_ms: int = 0) -> int:
    """Append to hint_requests. Returns the row id so it can be resolved later."""
    return conn.execute(
        """
        INSERT INTO hint_requests (
            student_id, lesson_step_id, question_id, quiz_id, help_type, tier,
            initiated_by, attempts_before, seconds_before, student_answer,
            response_text, engine, latency_ms, created_at
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (student_id, lesson_step_id, question_id, quiz_id, help_type, tier,
         initiated_by, attempts_before, seconds_before, student_answer,
         response_text, engine, latency_ms, economy.utc_now()),
    ).lastrowid


# =============================================================================
# 1. Re-explaining a lesson step
# =============================================================================

MODE_INSTRUCTIONS = {
    "simpler": ("The child did not understand this step. Say the SAME idea again "
                "using easier words and shorter sentences. Do not add new "
                "information. Do not skip ahead."),
    "example": ("Give ONE concrete everyday example of the idea in this step. "
                "Something a child would recognise — food, toys, family, school. "
                "Do not teach anything the step does not cover."),
    "another_way": ("Explain the SAME idea from a different angle. If the step used "
                    "objects, try actions. If it used numbers, try a picture in "
                    "words. Same content, different door in."),
}


def explain(
    conn: sqlite3.Connection,
    student_id: int,
    lesson_step_id: int,
    mode: str,
    *,
    initiated_by: str = "student",
    seconds_before: int = 0,
) -> TutorReply:
    """
    Re-explain one lesson step. This is the "I don't get this" button.

    Cached per (step, mode, support profile). Two reasons: tapping "say it
    another way" twice and getting a different answer each time is unsettling
    for exactly the users this app is for, and a cache hit is instant on a
    congested MiFi.
    """
    if mode not in MODE_INSTRUCTIONS:
        raise ValueError(f"Unknown explain mode: {mode}")

    step = conn.execute(
        """
        SELECT ls.*, l.title AS lesson_title, t.title AS topic_title, t.id AS topic_id
        FROM lesson_steps ls
        JOIN lessons l ON l.id = ls.lesson_id
        JOIN topics  t ON t.id = l.topic_id
        WHERE ls.id = ?
        """,
        (lesson_step_id,),
    ).fetchone()
    if step is None:
        raise ValueError(f"No lesson step {lesson_step_id}")

    profile = load_profile(conn, student_id)
    support = profile.get("support_profile") or "none"

    cached = conn.execute(
        "SELECT body, engine FROM step_explanations "
        "WHERE lesson_step_id = ? AND mode = ? AND support_profile = ?",
        (lesson_step_id, mode, support),
    ).fetchone()

    if cached:
        _log_help(conn, student_id, mode, lesson_step_id=lesson_step_id,
                  initiated_by=initiated_by, seconds_before=seconds_before,
                  response_text=cached["body"], engine="cache")
        _bump_step_help(conn, student_id, lesson_step_id)
        return TutorReply(text=cached["body"], engine=cached["engine"] or "cache",
                          latency_ms=0, grounded=True, cached=True,
                          suggested_topic_id=step["topic_id"])

    context = (f"Lesson: {step['lesson_title']}\nTopic: {step['topic_title']}\n"
               f"Step {step['step_no']}: {step['heading'] or ''}\n{step['body']}")

    result = llm.generate(
        MODE_INSTRUCTIONS[mode],
        context=context,
        student_profile=profile,
        max_tokens=220,
        temperature=0.6,
        fallback_text=_offline_explanation(step, mode),
    )

    if result.is_live:
        conn.execute(
            "INSERT OR REPLACE INTO step_explanations "
            "(lesson_step_id, mode, support_profile, body, engine, created_at) "
            "VALUES (?,?,?,?,?,?)",
            (lesson_step_id, mode, support, result.text, result.engine,
             economy.utc_now()),
        )

    _log_help(conn, student_id, mode, lesson_step_id=lesson_step_id,
              initiated_by=initiated_by, seconds_before=seconds_before,
              response_text=result.text, engine=result.engine,
              latency_ms=result.latency_ms)
    _bump_step_help(conn, student_id, lesson_step_id)

    return TutorReply(text=result.text, engine=result.engine,
                      latency_ms=result.latency_ms, grounded=True,
                      suggested_topic_id=step["topic_id"], error=result.error)


def _offline_explanation(step: sqlite3.Row, mode: str) -> str:
    """
    What Souly says when the LLM is unreachable.

    An earlier version returned `step["body"]` unchanged, which is technically
    grounded and useless: the child taps "I don't get this" and receives the
    identical sentence back, which reads as being ignored.

    So: say plainly that the clever explanation isn't available, then give the
    most useful thing we do have offline — the sentences broken up one at a
    time, or the key terms. Honest, and still worth reading.
    """
    body = (step["body"] or "").strip()
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", body) if s.strip()]

    if mode == "simpler":
        # One sentence at a time is a real simplification: it's the segmenting
        # principle, and it's something we can do without a model.
        if len(sentences) > 1:
            numbered = " ".join(f"{i}. {s}" for i, s in enumerate(sentences, 1))
            return ("Let's take it one bit at a time. " + numbered)
        return "Here it is again, slowly. " + body

    if mode == "example":
        terms = []
        if step["key_terms"]:
            try:
                terms = json.loads(step["key_terms"])
            except (json.JSONDecodeError, TypeError):
                terms = []
        if terms:
            return (f"I can't reach my examples right now. The important words "
                    f"here are {', '.join(terms)}. Try reading the step again "
                    f"and looking for those.")
        return ("I can't reach my examples right now. Read the step once more "
                "and see which part is the tricky bit.")

    # another_way
    if len(sentences) > 1:
        return ("I can't rewrite it right now, so here's the last part on its "
                "own — that's usually the bit that matters most. " + sentences[-1])
    return "I can't rewrite it right now. Here it is once more. " + body


def _bump_step_help(conn: sqlite3.Connection, student_id: int, step_id: int) -> None:
    conn.execute(
        """
        INSERT INTO step_activity (student_id, lesson_step_id, help_requests)
        VALUES (?, ?, 1)
        """,
        (student_id, step_id),
    )


# =============================================================================
# 2. The hint ladder
# =============================================================================

def hint(
    conn: sqlite3.Connection,
    student_id: int,
    question_id: int,
    tier: int,
    *,
    student_answer: str | None = None,
    quiz_id: int | None = None,
    attempts_before: int = 0,
    seconds_before: int = 0,
    initiated_by: str = "student",
) -> TutorReply:
    """
    One rung of the hint ladder for one question.

    The worked solution and the known wrong answers go into the prompt so the
    hint is CORRECT, and SOLUTION_PROMPT_RULES stops the model repeating them.
    That pairing is the Bastani guardrail — see llm.py.
    """
    tier = max(1, min(4, tier))

    question = conn.execute(
        """
        SELECT q.*, t.title AS topic_title, ls.body AS source_text
        FROM questions q
        JOIN topics t ON t.id = q.topic_id
        LEFT JOIN lesson_steps ls ON ls.id = q.source_step_id
        WHERE q.id = ?
        """,
        (question_id,),
    ).fetchone()
    if question is None:
        raise ValueError(f"No question {question_id}")

    options = json.loads(question["options"])
    correct = options[question["correct_index"]]

    # Everything the model needs to be right, none of it for the child's eyes.
    solution_block = [f"QUESTION: {question['prompt']}",
                      f"OPTIONS: {', '.join(options)}",
                      f"CORRECT ANSWER: {correct}"]
    if question["worked_solution"]:
        solution_block.append(f"WORKED SOLUTION: {question['worked_solution']}")
    elif question["explanation"]:
        solution_block.append(f"WHY: {question['explanation']}")

    if question["common_wrong_answers"]:
        try:
            wrongs = json.loads(question["common_wrong_answers"])
            lines = [f"  - {w['answer']}: {w['why']}" for w in wrongs]
            solution_block.append("COMMON MISTAKES:\n" + "\n".join(lines))
        except (json.JSONDecodeError, KeyError, TypeError):
            pass

    if question["source_text"]:
        solution_block.append(f"LESSON TEXT THIS CAME FROM: {question['source_text']}")

    if student_answer:
        solution_block.append(f"THE CHILD ANSWERED: {student_answer}")

    instruction = TIER_INSTRUCTIONS[tier]

    # Offline, tier 1 can still use the stored hint and tier 4 the stored
    # explanation. Tiers 2 and 3 degrade to the stored hint too — worse, but
    # never nothing.
    offline = {
        1: question["hint"] or "Have another look at the question.",
        2: question["hint"] or "Let's look at a similar one together.",
        3: question["hint"] or "Let's take it one step at a time.",
        4: f"The answer is {correct}. {question['explanation'] or ''}".strip(),
    }[tier]

    result = llm.generate(
        instruction,
        context="\n".join(solution_block),
        student_profile=load_profile(conn, student_id),
        extra_rules="" if tier == 4 else llm.SOLUTION_PROMPT_RULES,
        max_tokens=260,
        temperature=0.5,
        fallback_text=offline,
    )

    _log_help(conn, student_id, HINT_TIERS[tier], tier=tier,
              question_id=question_id, quiz_id=quiz_id,
              initiated_by=initiated_by, attempts_before=attempts_before,
              seconds_before=seconds_before, student_answer=student_answer,
              response_text=result.text, engine=result.engine,
              latency_ms=result.latency_ms)

    return TutorReply(
        text=result.text, engine=result.engine, latency_ms=result.latency_ms,
        grounded=True, tier=tier,
        next_tier=tier + 1 if tier < 4 else None,
        error=result.error,
    )


def resolve_hints(conn: sqlite3.Connection, student_id: int, question_id: int,
                  was_correct: bool) -> None:
    """
    Mark the outcome of any unresolved hints on this question.

    This is what turns hint_requests from a log into evidence: it lets us ask
    "after a tier-1 nudge, how often did the next attempt succeed?"
    """
    conn.execute(
        "UPDATE hint_requests SET resolved_correct = ? "
        "WHERE student_id = ? AND question_id = ? AND resolved_correct IS NULL",
        (int(was_correct), student_id, question_id),
    )


# =============================================================================
# 3. Question generation
# =============================================================================

def generate_questions(
    conn: sqlite3.Connection,
    lesson_id: int,
    *,
    count: int = 4,
    student_id: int | None = None,
    step_id: int | None = None,
    persist: bool = True,
) -> dict:
    """
    Build practice questions from the lesson's own text.

    This is the LLM doing something the question bank can't: producing fresh
    items so a student who repeats a lesson doesn't see the same four questions
    every time.

    Three safeguards, because a wrong question in front of a child with a
    learning disability is worse than a boring one:

      1. The model only sees this lesson's verified text, and is told every
         question must be answerable from it alone.
      2. Everything it returns goes through `_validate_question()` — shape,
         duplicate options, index range, answer-leaking prompts.
      3. Stored as origin='generated', review_status='pending', so a teacher
         can see exactly what the machine wrote and approve or bin it.

    Returns {"questions": [...], "engine": ..., "rejected": n, "reasons": [...]}
    """
    lesson = conn.execute(
        """
        SELECT l.*, t.id AS topic_id, t.title AS topic_title, t.is_verified AS topic_verified
        FROM lessons l JOIN topics t ON t.id = l.topic_id
        WHERE l.id = ?
        """,
        (lesson_id,),
    ).fetchone()
    if lesson is None:
        raise ValueError(f"No lesson {lesson_id}")

    # The verification rule holds here too: no generating from unapproved text.
    if not (lesson["is_verified"] and lesson["topic_verified"]):
        return {"questions": [], "engine": "none", "rejected": 0,
                "reasons": ["Lesson is not verified — cannot generate from it"]}

    if step_id:
        steps = conn.execute(
            "SELECT * FROM lesson_steps WHERE id = ?", (step_id,)
        ).fetchall()
    else:
        steps = conn.execute(
            "SELECT * FROM lesson_steps WHERE lesson_id = ? ORDER BY step_no",
            (lesson_id,),
        ).fetchall()

    if not steps:
        return {"questions": [], "engine": "none", "rejected": 0,
                "reasons": ["Lesson has no content"]}

    source = "\n\n".join(
        f"Step {s['step_no']}: {s['heading'] or ''}\n{s['body']}" for s in steps
    )

    # Aim the difficulty at where this student actually is.
    difficulty_hint = "mixed, from easy to medium"
    if student_id:
        row = conn.execute(
            "SELECT level FROM mastery WHERE student_id = ? AND topic_id = ?",
            (student_id, lesson["topic_id"]),
        ).fetchone()
        mastery = row["level"] if row else 0.0
        if mastery < 0.3:
            difficulty_hint = "easy — difficulty 1 or 2"
        elif mastery > 0.7:
            difficulty_hint = "harder — difficulty 3 or 4"
        else:
            difficulty_hint = "medium — difficulty 2 or 3"

    instruction = f"""Write {count} multiple-choice practice questions about the lesson
"{lesson['title']}" ({lesson['topic_title']}).

Rules:
- Every question must be answerable using ONLY the source material. Do not use
  outside knowledge.
- Exactly 4 options each. Exactly one is correct.
- Wrong options must be PLAUSIBLE mistakes a child could really make — not
  silly. A child learns nothing from ruling out an obviously absurd option.
- `explanation` teaches why the answer is right, in one or two short sentences.
- `hint` points at what to look at, WITHOUT giving the answer away.
- `worked_solution` shows the full reasoning. The tutor reads this so its hints
  are correct; the child never sees it.
- `common_wrong_answers` lists the tempting wrong options and the specific
  misunderstanding behind each one.
- Difficulty: {difficulty_hint}.
- Short sentences. Simple words. No idioms, no rhetorical questions.
"""

    result = llm.generate_json(instruction, schema=llm.QUESTION_SCHEMA,
                               context=source, temperature=0.7)

    if not result.ok:
        return {"questions": [], "engine": "fallback", "rejected": 0,
                "reasons": [result.error or "Generation unavailable"]}

    raw = result.data.get("questions", []) if isinstance(result.data, dict) else []
    accepted, reasons = [], []

    for item in raw:
        problem = _validate_question(item)
        if problem:
            reasons.append(problem)
            continue
        accepted.append(item)

    stored = []
    if persist and accepted:
        for item in accepted:
            question_id = _store_generated(conn, lesson, item,
                                           step_id or steps[0]["id"])
            stored.append({**item, "id": question_id})

    return {
        "questions": stored if persist else accepted,
        "engine": result.engine,
        "generated": len(raw),
        "accepted": len(accepted),
        "rejected": len(raw) - len(accepted),
        "reasons": reasons,
        "latency_ms": result.latency_ms,
    }


def _validate_question(item: dict) -> str | None:
    """
    Reject anything malformed. Returns a reason string, or None if it's fine.

    Constrained decoding guarantees the shape; this checks the content is
    usable. The answer-leak check matters most: a model asked for a hint-free
    prompt will still sometimes write "Which is correct: 5/8 (the answer)?"
    """
    prompt = (item.get("prompt") or "").strip()
    options = item.get("options") or []
    index = item.get("correct_index")

    if len(prompt) < 8:
        return f"Prompt too short: {prompt!r}"
    if len(options) != 4:
        return f"Expected 4 options, got {len(options)}: {prompt[:40]}"
    if any(not str(o).strip() for o in options):
        return f"Blank option in: {prompt[:40]}"
    if len({str(o).strip().lower() for o in options}) != 4:
        return f"Duplicate options in: {prompt[:40]}"
    if not isinstance(index, int) or not (0 <= index < 4):
        return f"correct_index {index} out of range: {prompt[:40]}"
    if not (item.get("explanation") or "").strip():
        return f"No explanation: {prompt[:40]}"
    if not (item.get("worked_solution") or "").strip():
        return f"No worked solution: {prompt[:40]}"

    # The prompt must not contain the correct option verbatim — that's a
    # giveaway, and models do it more often than you'd expect.
    correct = str(options[index]).strip().lower()
    if len(correct) > 3 and correct in prompt.lower():
        return f"Prompt leaks the answer: {prompt[:40]}"

    # Nor may the hint.
    hint_text = (item.get("hint") or "").strip().lower()
    if len(correct) > 3 and correct in hint_text:
        return f"Hint leaks the answer: {prompt[:40]}"

    return None


def _store_generated(conn: sqlite3.Connection, lesson: sqlite3.Row,
                     item: dict, source_step_id: int) -> int:
    from app.config import settings

    difficulty = item.get("difficulty", 2)
    if not isinstance(difficulty, int) or not (1 <= difficulty <= 5):
        difficulty = 2

    return conn.execute(
        """
        INSERT INTO questions (
            topic_id, lesson_id, source_step_id, prompt, options, correct_index,
            explanation, hint, worked_solution, common_wrong_answers,
            difficulty, origin, is_verified, review_status,
            generated_at, generated_model, created_at
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?, 'generated', 0, 'pending', ?,?,?)
        """,
        (
            lesson["topic_id"], lesson["id"], source_step_id,
            item["prompt"], json.dumps(item["options"]), item["correct_index"],
            item.get("explanation"), item.get("hint"),
            item.get("worked_solution"),
            json.dumps(item.get("common_wrong_answers") or []),
            difficulty, economy.utc_now(), settings.gemini_model,
            economy.utc_now(),
        ),
    ).lastrowid


# =============================================================================
# 4. Stall detection
# =============================================================================

def stall_threshold(conn: sqlite3.Connection, student_id: int) -> int:
    """
    How many seconds of no progress means this student is stuck.

    Calibrated to the student's own median step time, not a global constant.
    Autistic people are measurably slower across the board (Zapparrata 2023,
    g = .35), so a fixed threshold would mark the entire target cohort as
    permanently stalled — and then interrupt them, which is the specific harm
    the research warns about.
    """
    rows = conn.execute(
        "SELECT seconds_on_step FROM step_activity "
        "WHERE student_id = ? AND seconds_on_step > 0 "
        "ORDER BY id DESC LIMIT 20",
        (student_id,),
    ).fetchall()

    if len(rows) < 4:
        # Not enough live data yet. The entry activity measured how long this
        # child takes to make a first attempt, so use that instead of guessing
        # — it's the whole reason we collect it on day one.
        measured = conn.execute(
            "SELECT median_first_attempt_ms FROM v_current_learner_profile "
            "WHERE student_id = ?",
            (student_id,),
        ).fetchone()
        if measured and measured["median_first_attempt_ms"]:
            baseline = measured["median_first_attempt_ms"] / 1000
            return int(max(STALL_FLOOR_SECONDS,
                           min(STALL_CEILING_SECONDS,
                               baseline * STALL_MULTIPLIER * 2)))
        return STALL_FLOOR_SECONDS * 2   # generous until we know them

    values = sorted(r["seconds_on_step"] for r in rows)
    median = values[len(values) // 2]
    return int(max(STALL_FLOOR_SECONDS,
                   min(STALL_CEILING_SECONDS, median * STALL_MULTIPLIER)))


def should_offer_help(
    conn: sqlite3.Connection,
    student_id: int,
    *,
    seconds_on_step: int,
    wrong_attempts: int = 0,
    already_offered: bool = False,
) -> dict:
    """
    Should Souly speak first?

    Two triggers, both about PROGRESS rather than attention:
      * two wrong attempts on the same item
      * idle for longer than this student's own stall threshold

    Deliberately NOT triggered by looking away. Autistic children avert their
    gaze MORE as a task gets harder (Doherty-Sneddon 2012) — it reduces
    cognitive load so they can think. Offering help then interrupts them at
    the worst possible moment.
    """
    if already_offered:
        return {"offer": False, "reason": "already offered on this step"}

    if wrong_attempts >= 2:
        return {"offer": True, "reason": "two wrong attempts", "tier": 1}

    threshold = stall_threshold(conn, student_id)
    if seconds_on_step >= threshold:
        return {"offer": True, "reason": f"idle {seconds_on_step}s (threshold {threshold}s)",
                "tier": 1, "threshold": threshold}

    return {"offer": False, "reason": "making progress", "threshold": threshold}


# =============================================================================
# 5. Free-form questions
# =============================================================================

def _detect_mode_intent(text: str) -> str | None:
    """Cheap local intent check, so obvious requests don't wait on a round trip."""
    lowered = text.lower().strip()
    if any(w in lowered for w in ("quiz me", "test me", "give me a quiz",
                                  "make a quiz", "create a quiz")):
        return "quiz"
    if any(w in lowered for w in ("give me a game", "play a game", "let's play",
                                  "i want a game")):
        return "game"
    return None


def answer(
    conn: sqlite3.Connection,
    student_id: int,
    message: str,
    *,
    input_mode: str = "text",
    stt_confidence: float | None = None,
    session_id: int | None = None,
    topic_id: int | None = None,
    lesson_step_id: int | None = None,
    award_stars: bool = True,
) -> TutorReply:
    """
    A free-form question, still anchored to the lesson when there is one.

    If `lesson_step_id` is set, that step's text is put first in the context —
    the child is almost always asking about the thing in front of them, and
    retrieval alone can drift to a different lesson that shares vocabulary.
    """
    message = (message or "").strip()
    if not message:
        return TutorReply(text="I didn't catch that. Can you say it again?",
                          engine="none", latency_ms=0, error="Empty message")

    conn.execute(
        """
        INSERT INTO chat_messages (student_id, session_id, role, content,
                                   input_mode, stt_confidence, lesson_step_id)
        VALUES (?,?,'student',?,?,?,?)
        """,
        (student_id, session_id, message, input_mode, stt_confidence, lesson_step_id),
    )

    suggested_mode = _detect_mode_intent(message)

    context_parts, refs = [], []

    if lesson_step_id:
        step = conn.execute(
            """
            SELECT ls.body, ls.heading, ls.step_no, l.title AS lesson_title,
                   t.title AS topic_title, t.id AS topic_id
            FROM lesson_steps ls
            JOIN lessons l ON l.id = ls.lesson_id
            JOIN topics  t ON t.id = l.topic_id
            WHERE ls.id = ?
            """,
            (lesson_step_id,),
        ).fetchone()
        if step:
            context_parts.append(
                f"[ON SCREEN RIGHT NOW] {step['topic_title']} > {step['lesson_title']}, "
                f"step {step['step_no']}: {step['heading'] or ''}\n{step['body']}"
            )
            refs.append({"topic": step["topic_title"], "lesson": step["lesson_title"],
                         "step": step["step_no"], "on_screen": True})
            topic_id = topic_id or step["topic_id"]

    chunks = rag.search(conn, message, limit=3, topic_id=topic_id)
    if chunks:
        context_parts.append(rag.build_context(chunks))
        refs.extend(c.to_ref() for c in chunks)

    context = "\n\n".join(context_parts)

    result = llm.generate(
        message,
        context=context,
        history=load_history(conn, student_id),
        student_profile=load_profile(conn, student_id),
        suggestions=available_topics(conn) if not context else None,
    )

    conn.execute(
        """
        INSERT INTO chat_messages (student_id, session_id, role, content,
                                   input_mode, engine, latency_ms, source_refs,
                                   lesson_step_id, help_type)
        VALUES (?,?,'souly',?,'text',?,?,?,?, 'free_question')
        """,
        (student_id, session_id, result.text, result.engine, result.latency_ms,
         json.dumps(refs) if refs else None, lesson_step_id),
    )

    _log_help(conn, student_id, "free_question", lesson_step_id=lesson_step_id,
              response_text=result.text, engine=result.engine,
              latency_ms=result.latency_ms, student_answer=message)

    award_dict = None
    if award_stars:
        award_dict = economy.award(
            conn, student_id, "chat_question",
            stars=economy.STARS_PER_CHAT_QUESTION,
            xp=economy.XP_PER_CHAT_QUESTION,
            topic_id=topic_id, duration_s=5, detail=message[:120],
        ).to_dict()

    return TutorReply(
        text=result.text, engine=result.engine, latency_ms=result.latency_ms,
        source_refs=refs, grounded=bool(context), award=award_dict,
        suggested_mode=suggested_mode, suggested_topic_id=topic_id,
        error=result.error,
    )


# =============================================================================
# 6. Greeting
# =============================================================================

def greeting(conn: sqlite3.Connection, student_id: int) -> str:
    """
    Souly's opening line, built from real state.

    Note what it never says: nothing about always being here, nothing about
    friendship, nothing about having missed them. Moxie — a companion robot
    sold for autistic children — bricked every unit when its company folded,
    and the children who had been told it was their best friend were the ones
    who took it hardest. Souly is a study buddy for a study session.
    """
    profile = load_profile(conn, student_id)
    name = profile.get("display_name", "friend")

    in_progress = conn.execute(
        """
        SELECT l.title FROM lesson_progress lp
        JOIN lessons l ON l.id = lp.lesson_id
        WHERE lp.student_id = ? AND lp.is_complete = 0 AND lp.steps_completed > 0
        ORDER BY lp.updated_at DESC LIMIT 1
        """,
        (student_id,),
    ).fetchone()

    if in_progress:
        return f"Hi {name}. You were on {in_progress['title']}. Want to carry on?"

    has_content = conn.execute(
        "SELECT COUNT(*) c FROM lessons WHERE is_verified = 1"
    ).fetchone()["c"]
    if not has_content:
        return f"Hi {name}. No lessons are loaded yet — ask your teacher to add some."

    return f"Hi {name}. I'm Souly. Ready when you are."

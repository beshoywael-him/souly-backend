/* =============================================================================
   Souly — page renderers.

   One function per screen. Each takes live API data and returns HTML.
   No page holds its own copy of a number; they all read from State, which is
   updated from award responses, so two screens can never disagree.

   The lesson screen is the centre of the app now. Everything else exists to
   get a child into it or to celebrate them coming out of it.
   ============================================================================= */

const Pages = (() => {
  'use strict';

  const E = Util.esc;

  /* --- Shared bits ---------------------------------------------------------- */

  function soulyFace(size) {
    const cls = size === 'big' ? '' : 'robot-mini';
    return `<div class="${cls}"><div class="robot-head"><div class="robot-face">
      <div class="robot-eye left"></div><div class="robot-eye right"></div>
      <div class="robot-smile"></div></div></div></div>`;
  }

  function topBar(icon, title, subtitle, backPage) {
    return `<div class="top-bar" style="padding:4px 0 10px;">
      <div class="top-bar-left">
        ${backPage ? `<button class="top-bar-back" onclick="App.go('${backPage}')" aria-label="Go back">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>` : ''}
        <div>
          <div class="top-bar-title">${icon} ${E(title)}</div>
          ${subtitle ? `<div class="top-bar-sub">${E(subtitle)}</div>` : ''}
        </div>
      </div>
    </div>`;
  }

  /* Split the body text into word spans so read-aloud can highlight along.
     Synchronised highlighting is what makes narration-plus-text help rather
     than compete: the two channels index each other. */
  function wordSpans(text) {
    return E(text)
      .split(/(\s+)/)
      .map(tok => (/^\s+$/.test(tok) ? tok : `<span class="w">${tok}</span>`))
      .join('');
  }

  /* ==========================================================================
     PLAN STRIP — the visual schedule, always on screen
     ========================================================================== */

  function planStrip(plan, profile) {
    if (!plan) return '';
    const item = (key, label, icon) => {
      const state = plan[key] ? 'done' : (plan.current === key ? 'current' : '');
      return `<span class="plan-item ${state}">
        <span>${plan[key] ? '✓' : icon}</span>
        <span class="plan-text">${label}</span>
      </span>`;
    };
    return `
      <span class="plan-label">Today</span>
      ${item('lesson_done', 'Lesson', '📘')}
      ${item('quiz_done', 'Practice', '✏️')}
      ${item('game_done', 'Game', '🎮')}
      <span class="plan-spacer"></span>
      ${profile ? `<span class="plan-stat" data-bind="stars">⭐ ${Util.num(profile.stars)}</span>
      <span class="plan-stat" data-bind="streak">🔥 ${profile.day_streak}</span>` : ''}
    `;
  }

  /* ==========================================================================
     HOME — start or resume a session
     ========================================================================== */

  function home(data) {
    const p = data.profile;
    const lesson = data.todays_lesson;

    const flagNotice = data.pending_flags > 0
      ? `<div class="notice-strip">👋 Ready when you are — we can pick up where you left off.</div>`
      : '';

    return `
      <div class="home-header" style="padding:6px 0 12px;">
        <div>
          <div class="greeting">${E(data.greeting)}</div>
          <div class="greeting-sub">${E(data.greeting_sub)}</div>
        </div>
      </div>

      ${flagNotice}

      <div class="glass-card">
        <div class="speech-wrap">
          ${soulyFace()}
          <div class="speech-bubble" id="homeSoulyMsg">${E(data.souly_message)}</div>
          <button class="speak-btn" onclick="Voice.speakElement('homeSoulyMsg', this)" aria-label="Read aloud">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3a4.5 4.5 0 00-2.5-4v8a4.5 4.5 0 002.5-4z"/></svg>
          </button>
        </div>
      </div>

      ${lesson ? `
      <div class="continue-card">
        <div class="continue-art">${lesson.icon || '📘'}</div>
        <div style="flex:1; min-width:0;">
          <div style="font-size:12px; color:#a78bfa; font-weight:700;">${lesson.steps_completed > 0 ? 'Carry on with' : 'Starting today'}</div>
          <div style="font-size:20px; font-weight:800; color:#4c1d95; margin:4px 0 10px;">${E(lesson.title)}</div>
          <div class="progress-bar-bg" style="margin-bottom:6px;">
            <div class="progress-bar-fill" style="width:${lesson.progress_pct}%; background:linear-gradient(90deg,#7C3AED,#A855F7);"></div>
          </div>
          <div style="font-size:12px; color:#a78bfa; font-weight:600;">${lesson.steps_completed} of ${lesson.total_steps} steps</div>
        </div>
        <button class="btn-primary" style="flex-shrink:0;" onclick="App.openLesson(${lesson.lesson_id})">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
          ${lesson.steps_completed > 0 ? 'Carry on' : 'Start'}
        </button>
      </div>` : Util.empty('📚', 'No lessons are loaded yet. Your teacher needs to add the curriculum.')}

      <div class="card-row" style="margin-top:16px;">
        <div class="qa-card" onclick="App.go('learn')" role="button" tabindex="0">
          <div class="qa-icon">📚</div><div class="qa-title">Learn</div><div class="qa-desc">Pick a topic</div>
        </div>
        <div class="qa-card" onclick="App.go('progress')" role="button" tabindex="0">
          <div class="qa-icon">📊</div><div class="qa-title">Progress</div><div class="qa-desc">How you're doing</div>
        </div>
        <div class="qa-card" onclick="App.go('games')" role="button" tabindex="0">
          <div class="qa-icon">🎮</div><div class="qa-title">Games</div><div class="qa-desc">After your lesson</div>
        </div>
        <div class="qa-card" onclick="App.go('achievements')" role="button" tabindex="0">
          <div class="qa-icon">🏆</div><div class="qa-title">Badges</div><div class="qa-desc">${p.badges_earned} earned</div>
        </div>
      </div>

      ${data.schedule && data.schedule.length ? `
      <div class="section-title-sm">Today's timetable</div>
      <div class="card-row">
        ${data.schedule.map(s => `
          <div style="display:flex; align-items:center; gap:12px; padding:12px 14px; background:#f5f3ff; border-radius:14px;">
            <span style="font-size:20px;">${s.icon}</span>
            <div style="font-size:13px; font-weight:700; color:#4c1d95;">
              ${Util.time12(s.time)} · ${E(s.label)}
            </div>
          </div>`).join('')}
      </div>` : ''}
    `;
  }

  /* ==========================================================================
     LEARN — subject rail + learning path
     ========================================================================== */

  function learn(data) {
    const notice = data.has_content === false
      ? `<div class="notice-strip">📭 No lessons have been added yet.</div>` : '';

    return `
      ${topBar('📚', 'Learn', 'Pick where you want to go', 'home')}
      ${notice}

      <div class="subject-rail" id="subjectRail" role="tablist">
        ${data.subjects.map(s => {
          const empty = s.topic_count === 0;
          return `<button class="subject-chip ${empty ? 'empty' : ''}" data-code="${s.code}"
                    ${empty ? 'disabled' : `onclick="App.openSubject('${s.code}')"`}
                    role="tab" aria-selected="false">
            <span class="chip-ico">${s.icon}</span>
            <span>${E(s.name)}</span>
            <span class="chip-pct">${empty ? '—' : s.progress_pct + '%'}</span>
          </button>`;
        }).join('')}
      </div>

      <div id="pathArea">
        ${data.has_content === false
          ? Util.empty('🌱', "Once your teacher loads some lessons, they'll appear here as a path you can follow.")
          : Util.empty('👆', 'Choose a subject to see its lessons.')}
      </div>
    `;
  }

  /* The learning path. Replaces the flat icon grid: bigger cards, real
     artwork, and the sequence made visible — done, current, next. */
  function learningPath(subjectName, lessons) {
    if (!lessons.length) return Util.empty('📭', `No lessons in ${subjectName} yet.`);

    const firstUnfinished = lessons.findIndex(l => !l.is_complete);

    const card = (l, index) => {
      const isCurrent = index === firstUnfinished;
      const state = l.is_complete ? 'done' : (isCurrent ? 'current' : '');
      const statusLabel = l.is_complete
        ? `<span class="path-status done">✓ Finished</span>`
        : isCurrent
          ? `<span class="path-status current">${l.steps_completed > 0 ? 'Carry on' : 'Start here'}</span>`
          : `<span class="path-status todo">Coming up</span>`;

      const art = l.image_url
        ? `<img src="${E(l.image_url)}" alt="">`
        : `<span>${l.icon || '📘'}</span>`;

      return `
        <div class="path-node">
          <button class="path-card ${state}" onclick="App.openLesson(${l.id})"
                  aria-label="${E(l.title)}, ${l.is_complete ? 'finished' : l.progress_pct + ' percent done'}">
            <div class="path-art" style="background:linear-gradient(135deg, ${l.color_from || '#f5f3ff'}, ${l.color_to || '#ede9fe'});">${art}</div>
            <div class="path-title">${E(l.title)}</div>
            <div class="path-sub">${l.total_steps} steps · ${l.estimated_min} min</div>
            <div class="path-foot">
              <div class="sub-bar" style="margin-bottom:8px;">
                <div class="sub-bar-fill" style="width:${l.progress_pct}%; background:linear-gradient(90deg,#7C3AED,#A855F7);"></div>
              </div>
              ${statusLabel}
            </div>
          </button>
        </div>
        ${index < lessons.length - 1
          ? `<div class="path-link ${l.is_complete ? 'done' : ''}"></div>` : ''}
      `;
    };

    return `
      <div class="section-title-sm">${E(subjectName)} — your path</div>
      <div class="path">${lessons.map(card).join('')}</div>
    `;
  }

  /* ==========================================================================
     LESSON — the two-pane screen. This is the app.
     ========================================================================== */

  function lesson(data, stepNo, soulyState) {
    const step = data.steps[stepNo - 1];
    if (!step) return Util.empty('📄', 'This lesson has no content yet.');

    const isLast = stepNo >= data.steps.length;

    return `
      ${topBar(data.icon, data.title, `${E(data.subject_name || '')} · step ${stepNo} of ${data.steps.length}`, 'learn')}

      <div class="split-body">

        <!-- LEFT: the explanation. Stays on screen while help happens. -->
        <section class="pane pane-content" aria-label="Lesson content">
          <div class="glass-card" style="flex:1; display:flex; flex-direction:column;">
            ${step.visual || step.image_url ? `<div class="lesson-visual">
              ${step.image_url ? `<img src="${E(step.image_url)}" alt="">` : step.visual}
            </div>` : ''}

            ${step.heading ? `<div class="lesson-heading">${E(step.heading)}</div>` : ''}

            <div class="lesson-body" id="lessonBody">${wordSpans(step.body)}</div>

            ${step.key_terms && step.key_terms.length ? `
              <div class="key-terms">
                ${step.key_terms.map(t => `<span class="key-term">${E(t)}</span>`).join('')}
              </div>` : ''}

            <div class="step-dots" aria-label="Step ${stepNo} of ${data.steps.length}">
              ${data.steps.map((_, i) =>
                `<div class="step-dot ${i + 1 === stepNo ? 'active' : (i + 1 < stepNo ? 'done' : '')}"></div>`
              ).join('')}
            </div>

            <div class="step-nav">
              <button class="btn-secondary" onclick="App.lessonStep(${stepNo - 1})"
                      ${stepNo === 1 ? 'disabled' : ''}>Back</button>
              <button class="btn-primary" onclick="App.lessonStep(${stepNo + 1})">
                ${isLast ? 'Finish' : 'Next'}
              </button>
            </div>
          </div>
        </section>

        <!-- RIGHT: Souly. Never a separate screen. -->
        <aside class="pane pane-souly" aria-label="Souly">
          <div class="souly-head">
            ${soulyFace()}
            <div>
              <div class="souly-name">Souly</div>
              <div class="souly-state" id="soulyState">${soulyState || 'Here if you need me'}</div>
            </div>
            <div style="margin-left:auto;">
              <button class="speak-btn" onclick="App.readStep(this)" aria-label="Read the lesson aloud">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3a4.5 4.5 0 00-2.5-4v8a4.5 4.5 0 002.5-4z"/></svg>
              </button>
            </div>
          </div>

          <div class="souly-say" id="soulySay">${E(data.souly_intro || "Tap a button below if any part of this is confusing. Asking is normal — I'd rather you asked.")}</div>

          <div class="help-buttons">
            <button class="help-btn" onclick="App.askHelp('simpler')">
              <span class="help-ico">🤔</span><span>I don't get this</span>
            </button>
            <button class="help-btn" onclick="App.askHelp('example')">
              <span class="help-ico">💡</span><span>Show me an example</span>
            </button>
            <button class="help-btn" onclick="App.askHelp('another_way')">
              <span class="help-ico">🔄</span><span>Say it another way</span>
            </button>
          </div>

          <div class="voice-status" id="voiceStatus"></div>

          <div class="ask-row">
            <input class="input-field" id="askInput" placeholder="Or ask me anything…"
                   autocomplete="off" aria-label="Ask Souly a question"
                   onkeydown="if(event.key==='Enter'){App.askFree()}">
            <button class="voice-btn" id="voiceBtn" onclick="Voice.toggle()" aria-label="Talk to Souly">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 14a3 3 0 003-3V5a3 3 0 00-6 0v6a3 3 0 003 3z"/><path d="M17 11a5 5 0 01-10 0H5a7 7 0 006 6.92V21h2v-3.08A7 7 0 0019 11z"/></svg>
            </button>
          </div>
        </aside>

      </div>
    `;
  }

  /* ==========================================================================
     PRACTICE — question left, hint ladder right
     ========================================================================== */

  function practice(state) {
    const q = state.question;
    if (!q) return Util.empty('🎉', 'No question loaded.');

    return `
      ${topBar('✏️', 'Practice', `${E(state.lesson_title || '')} · ${state.index + 1} of ${state.total}`, 'lesson')}

      <div class="split-body">

        <section class="pane pane-content" aria-label="Question">
          <div class="glass-card" style="flex:1; display:flex; flex-direction:column;">
            <div class="practice-origin">
              ${q.origin === 'generated'
                ? `<span class="gen">✨ Souly wrote this from your lesson</span>`
                : 'From the question bank'}
            </div>
            <div class="practice-question" id="practicePrompt">${E(q.prompt)}</div>

            <div id="practiceOptions" style="margin-top:14px;">
              ${q.options.map((opt, i) => `
                <button class="quiz-option" onclick="App.answerPractice(${i})">
                  <span class="opt-letter">${String.fromCharCode(65 + i)}</span>
                  <span>${E(opt)}</span>
                </button>`).join('')}
            </div>

            <div id="practiceFeedback"></div>

            <div class="step-dots" style="margin-top:auto;">
              ${Array.from({length: state.total}, (_, i) =>
                `<div class="step-dot ${i === state.index ? 'active' : (i < state.index ? 'done' : '')}"></div>`
              ).join('')}
            </div>
          </div>
        </section>

        <aside class="pane pane-souly" aria-label="Souly">
          <div class="souly-head">
            ${soulyFace()}
            <div>
              <div class="souly-name">Souly</div>
              <div class="souly-state" id="soulyState">Stuck? I'll give you a clue, not the answer.</div>
            </div>
          </div>

          <div class="hint-ladder" id="hintLadder"></div>

          <button class="hint-more" id="hintMore" onclick="App.nextHint()">
            💡 Give me a clue
          </button>
          <div class="hint-free-note">Asking for help never costs you stars.</div>

          <div class="voice-status" id="voiceStatus"></div>
          <div class="ask-row">
            <input class="input-field" id="askInput" placeholder="Ask me something…"
                   autocomplete="off" aria-label="Ask Souly a question"
                   onkeydown="if(event.key==='Enter'){App.askFree()}">
            <button class="voice-btn" id="voiceBtn" onclick="Voice.toggle()" aria-label="Talk to Souly">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 14a3 3 0 003-3V5a3 3 0 00-6 0v6a3 3 0 003 3z"/><path d="M17 11a5 5 0 01-10 0H5a7 7 0 006 6.92V21h2v-3.08A7 7 0 0019 11z"/></svg>
            </button>
          </div>
        </aside>

      </div>
    `;
  }

  function hintStep(tier, text) {
    const labels = { 1: '1', 2: '2', 3: '3', 4: '✓' };
    return `<div class="hint-step">
      <span class="hint-tier-badge">${labels[tier] || tier}</span>
      <div class="hint-text">${E(text)}</div>
    </div>`;
  }

  function practiceComplete(state) {
    const pct = state.total ? Math.round((state.correct / state.total) * 100) : 0;
    return `
      ${topBar('🎉', 'Practice done', E(state.lesson_title || ''), 'learn')}
      <div class="card-row">
        <div class="glass-card" style="text-align:center;">
          <div style="font-size:60px;">${pct >= 70 ? '🏆' : '💪'}</div>
          <div style="font-size:22px; font-weight:800; color:#4c1d95; margin-top:8px;">
            ${state.correct} of ${state.total}
          </div>
          <div style="font-size:13px; color:#a78bfa; font-weight:600; margin-top:4px;">
            ${state.hints_used ? `You used ${state.hints_used} clue${state.hints_used > 1 ? 's' : ''} — that's good learning.` : 'No clues needed!'}
          </div>
        </div>
        <div class="glass-card">
          <div class="speech-wrap">
            ${soulyFace()}
            <div class="speech-bubble">${E(
              pct >= 70 ? "Nice work. You've got this one."
              : "Good effort. Some of those were tricky — we can go through them again whenever you like."
            )}</div>
          </div>
          <div style="display:flex; gap:10px; margin-top:16px;">
            <button class="btn-secondary" style="flex:1;" onclick="App.go('learn')">Back to Learn</button>
            <button class="btn-primary" style="flex:1; justify-content:center;" onclick="App.go('games')">Play a game</button>
          </div>
        </div>
      </div>
    `;
  }

  /* ==========================================================================
     PROGRESS
     ========================================================================== */

  function progress(data) {
    return `
      ${topBar('📊', 'Progress', 'How you are getting on', 'home')}

      <div class="card-row">
        <div class="glass-card" style="text-align:center;">
          <div style="font-size:13px; color:#a78bfa; font-weight:700;">Level ${data.level.level} · ${E(data.level.title)}</div>
          <div class="circle-progress" style="margin-top:10px;">
            <svg width="120" height="120" viewBox="0 0 120 120">
              <circle class="circle-progress-bg" cx="60" cy="60" r="50"/>
              <circle class="circle-progress-fill" cx="60" cy="60" r="50" stroke-dasharray="314" stroke-dashoffset="${Util.ringOffset(data.overall_progress_pct)}"/>
            </svg>
            <div class="circle-progress-text">${data.overall_progress_pct}%</div>
          </div>
          <div style="display:flex; justify-content:center; gap:22px; margin-top:12px;">
            <div><div style="font-size:19px; font-weight:800; color:#7C3AED;">${Util.num(data.level.xp)}</div><div style="font-size:11px; color:#a78bfa; font-weight:600;">XP</div></div>
            <div><div style="font-size:19px; font-weight:800; color:#7C3AED;">⭐ ${Util.num(data.stars)}</div><div style="font-size:11px; color:#a78bfa; font-weight:600;">Stars</div></div>
            <div><div style="font-size:19px; font-weight:800; color:#7C3AED;">🔥 ${data.day_streak}</div><div style="font-size:11px; color:#a78bfa; font-weight:600;">Days</div></div>
          </div>
        </div>

        <div class="glass-card">
          <div class="glass-card-title">📅 This week</div>
          <div class="week-chart">
            ${data.week.map(d => `
              <div class="week-col ${d.is_today ? 'today' : ''} ${d.is_future ? 'future' : ''}">
                <div class="week-bar-track">
                  <div class="week-bar" style="height:${Math.max(d.height_pct, d.seconds > 0 ? 8 : 3)}%"></div>
                </div>
                <div class="week-label">${d.label}</div>
              </div>`).join('')}
          </div>
          <div style="display:flex; justify-content:space-around; margin-top:10px; text-align:center;">
            <div><div style="font-size:16px; font-weight:800; color:#7C3AED;">${data.time_spent.today_label}</div><div style="font-size:11px; color:#a78bfa; font-weight:600;">Today</div></div>
            <div><div style="font-size:16px; font-weight:800; color:#7C3AED;">${data.time_spent.week_label}</div><div style="font-size:11px; color:#a78bfa; font-weight:600;">This week</div></div>
          </div>
        </div>
      </div>

      <div class="card-row" style="margin-top:14px;">
        <div class="glass-card">
          <div class="glass-card-title">📚 Subjects</div>
          <div style="margin-top:14px;">
            ${data.subjects.map(s => `
              <div style="margin-bottom:14px;">
                <div style="display:flex; justify-content:space-between; margin-bottom:6px;">
                  <span style="font-size:13px; font-weight:700; color:#4c1d95;">${s.icon} ${E(s.name)}</span>
                  <span style="font-size:13px; font-weight:800; color:#7C3AED;">${s.progress_pct}%</span>
                </div>
                <div class="progress-bar-bg">
                  <div class="progress-bar-fill" style="width:${s.progress_pct}%; background:linear-gradient(90deg,${s.color_from},${s.color_to});"></div>
                </div>
              </div>`).join('')}
          </div>
        </div>

        <div class="glass-card">
          <div class="glass-card-title">💡 Skills</div>
          <div style="margin-top:14px;">
            ${data.skills.map(s => `
              <div style="margin-bottom:12px;">
                <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                  <span style="font-size:13px; font-weight:700; color:#4c1d95;">${s.icon} ${E(s.name)}</span>
                  <span style="font-size:13px; font-weight:800; color:#7C3AED;">${s.level_pct}%</span>
                </div>
                <div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${s.level_pct}%; background:linear-gradient(90deg,#7C3AED,#A855F7);"></div></div>
              </div>`).join('')}
          </div>
        </div>
      </div>
    `;
  }

  /* ==========================================================================
     GAMES / REWARDS / ACHIEVEMENTS — session-end moments, not destinations
     ========================================================================== */

  function games(data) {
    return `
      ${topBar('🎮', 'Games', 'A break after your lesson', 'home')}
      <div class="card-row">
        ${data.games.map(g => `
          <div class="game-card" onclick="App.playGame(${g.id})" role="button" tabindex="0">
            <div class="game-icon">${g.icon}</div>
            <div class="game-info">
              <div class="game-name">${E(g.name)}</div>
              <div class="game-desc">${E(g.description)}</div>
              <div class="game-meta">
                <span class="game-badge" style="background:#fef3c7; color:#92400e;">+${g.star_reward} ⭐</span>
                <span class="game-badge" style="background:#ede9fe; color:#7C3AED;">${E(g.difficulty)}</span>
                ${g.times_played ? `<span class="game-badge" style="background:#dcfce7; color:#15803d;">Best ${g.best_score}</span>` : ''}
              </div>
            </div>
          </div>`).join('')}
      </div>
    `;
  }

  function achievements(data, profile) {
    const badgeCard = (b) => `
      <div class="badge-card ${b.unlocked ? '' : 'locked'}">
        <div class="badge-icon">${b.unlocked ? b.icon : '🔒'}</div>
        <div class="badge-name">${E(b.name)}</div>
        <div class="badge-desc">${E(b.description)}</div>
        ${b.unlocked
          ? `<div class="badge-status" style="background:#dcfce7; color:#15803d;">Earned</div>`
          : `<div class="badge-progress-bar"><div class="badge-progress-fill" style="width:${b.progress_pct}%"></div></div>
             <div class="badge-desc" style="margin-top:5px;">${b.progress} / ${b.target}</div>`}
      </div>`;

    return `
      ${topBar('🏆', 'Badges', `${data.earned_count} of ${data.total_count}`, 'home')}
      <div class="badge-grid" style="grid-template-columns:repeat(auto-fill,minmax(180px,1fr));">
        ${data.badges.map(badgeCard).join('')}
      </div>
    `;
  }

  function rewards(data) {
    return `
      ${topBar('🎁', 'Rewards', `You have ${Util.num(data.stars)} stars`, 'profile')}
      <div class="reward-grid" style="grid-template-columns:repeat(auto-fill,minmax(190px,1fr));">
        ${data.rewards.map(r => `
          <div class="reward-card ${r.owned ? 'owned' : (r.affordable ? '' : 'unaffordable')}">
            <div class="reward-icon">${r.icon}</div>
            <div class="reward-name">${E(r.name)}</div>
            <div class="reward-cost">⭐ ${Util.num(r.cost_stars)}</div>
            ${r.owned
              ? `<button class="btn-secondary" style="width:100%; ${r.equipped ? 'background:#dcfce7; color:#15803d;' : ''}"
                         onclick="App.equipReward(${r.id})">${r.equipped ? 'In use ✓' : 'Use'}</button>`
              : `<button class="btn-secondary" style="width:100%;" onclick="App.unlockReward(${r.id})"
                         ${r.affordable ? '' : 'disabled'}>
                   ${r.affordable ? 'Unlock' : `Need ${Util.num(r.stars_needed)}`}
                 </button>`}
          </div>`).join('')}
      </div>
    `;
  }

  /* ==========================================================================
     PROFILE
     ========================================================================== */

  function profile(p, s, health) {
    const toggle = (key, label, icon) => `
      <div class="setting-item">
        <div class="setting-left">
          <div class="setting-icon">${icon}</div>
          <div class="setting-name">${label}</div>
        </div>
        <div class="toggle ${s[key] ? 'on' : ''}" role="switch" aria-checked="${!!s[key]}"
             aria-label="${label}" tabindex="0" onclick="App.toggleSetting('${key}', this)">
          <div class="toggle-knob"></div>
        </div>
      </div>`;

    const segment = (key, options) => `
      <div class="seg-group">
        ${options.map(([value, label]) =>
          `<button class="seg-btn ${s[key] === value ? 'active' : ''}"
                   onclick="App.setSetting('${key}', '${value}')">${label}</button>`).join('')}
      </div>`;

    return `
      ${topBar('👤', 'Profile', E(p.full_name), 'home')}

      <div class="card-row">
        <div class="glass-card" style="text-align:center;">
          <div style="font-size:52px;">🧒</div>
          <div style="font-size:19px; font-weight:800; color:#4c1d95; margin-top:6px;">${E(p.display_name)}</div>
          <div style="font-size:13px; color:#a78bfa; font-weight:600;">Level ${p.level} · ${E(p.level_title)}</div>
          <div style="display:flex; justify-content:space-around; margin-top:16px;">
            <div><div style="font-size:18px; font-weight:800; color:#7C3AED;">${Util.num(p.stars)}</div><div style="font-size:11px; color:#a78bfa; font-weight:600;">Stars</div></div>
            <div><div style="font-size:18px; font-weight:800; color:#7C3AED;">${p.badges_earned}</div><div style="font-size:11px; color:#a78bfa; font-weight:600;">Badges</div></div>
            <div><div style="font-size:18px; font-weight:800; color:#7C3AED;">${p.lessons_completed}</div><div style="font-size:11px; color:#a78bfa; font-weight:600;">Lessons</div></div>
          </div>
          <button class="btn-secondary" style="width:100%; margin-top:16px;" onclick="App.go('rewards')">🎁 Rewards shop</button>
        </div>

        <div class="glass-card">
          <div class="glass-card-title">🔌 System</div>
          <div style="margin-top:12px; font-size:12px; font-weight:600; color:#a78bfa; line-height:2.1;">
            <div>AI brain: ${health && health.integrations.llm_gemini ? '🟢 Gemini connected' : '🟡 Offline mode'}</div>
            <div>Speech to text: ${health && health.integrations.stt_elevenlabs ? '🟢 ElevenLabs' : '🟡 Not configured'}</div>
            <div>Voice: ${health && health.integrations.tts ? '🟢 ' + health.tts_provider : '🟡 Browser voice'}</div>
            <div>Lessons loaded: ${health && health.curriculum ? health.curriculum.verified_lessons : '—'}</div>
          </div>
        </div>
      </div>

      <div class="section-title-sm">Preferences</div>
      <div class="card-row">
        <div>
          <div class="setting-item">
            <div class="setting-left"><div class="setting-icon">🔤</div><div class="setting-name">Text size</div></div>
            ${segment('font_size', [['small', 'S'], ['medium', 'M'], ['large', 'L']])}
          </div>
          <div class="setting-item">
            <div class="setting-left"><div class="setting-icon">🎨</div><div class="setting-name">Theme</div></div>
            ${segment('theme', [['light', 'Light'], ['purple', 'Calm'], ['dark', 'Dark']])}
          </div>
          <div class="setting-item">
            <div class="setting-left"><div class="setting-icon">🔊</div><div class="setting-name">Voice volume</div></div>
            <input type="range" class="range-slider" min="0" max="100" value="${s.voice_volume}"
                   aria-label="Voice volume" onchange="App.setSetting('voice_volume', Number(this.value))">
          </div>
          <div class="setting-item">
            <div class="setting-left"><div class="setting-icon">🌐</div><div class="setting-name">Language</div></div>
            ${segment('language', [['en', 'EN'], ['ar', 'AR'], ['fr', 'FR']])}
          </div>
        </div>

        <div>
          ${toggle('read_aloud', 'Read text aloud', '🗣️')}
          ${toggle('high_contrast', 'High contrast', '◐')}
          ${toggle('larger_buttons', 'Bigger buttons', '🔲')}
          ${toggle('reduce_motion', 'Less movement', '🌊')}
          ${toggle('closed_captions', 'Captions', '💬')}
          ${toggle('voice_commands', 'Voice commands', '🎤')}
        </div>
      </div>
    `;
  }

  return {
    planStrip, home, learn, learningPath, lesson,
    practice, hintStep, practiceComplete,
    progress, games, achievements, rewards, profile,
    soulyFace, topBar,
  };
})();
